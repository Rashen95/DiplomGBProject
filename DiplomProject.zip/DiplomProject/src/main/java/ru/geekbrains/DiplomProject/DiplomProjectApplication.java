package ru.geekbrains.DiplomProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DiplomProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(DiplomProjectApplication.class, args);
	}

}
