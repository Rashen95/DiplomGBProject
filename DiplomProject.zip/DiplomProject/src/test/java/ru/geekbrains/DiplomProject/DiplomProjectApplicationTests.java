package ru.geekbrains.DiplomProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiplomProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
